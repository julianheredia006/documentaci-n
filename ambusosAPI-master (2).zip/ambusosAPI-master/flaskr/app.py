from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api
from flask_migrate import Migrate
from .modelos.modelo import db
from .vistas.vistas import (
    VistaAmbulancias,
    VistaAmbulancia,
    VistaPersonalAmbulancia,
    VistaMiembroPersonal,
    VistaFormularioAccidente,
    VistaAccidente,
    VistaReportesViajes,
    VistaReporteViaje
)

def create_app():
    app = Flask(__name__)
    
    # Configuración de la base de datos
    app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/julian'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Inicialización de la base de datos y migración
    db.init_app(app)
    migrate = Migrate(app, db)

    # Configuración de la API RESTful
    api = Api(app)
    api.add_resource(VistaAmbulancias, '/ambulancias')
    api.add_resource(VistaAmbulancia, '/ambulancias/<int:id_ambulancia>')
    api.add_resource(VistaPersonalAmbulancia, '/ambulancias/<int:id_ambulancia>/personal')
    api.add_resource(VistaMiembroPersonal, '/ambulancias/<int:id_ambulancia>/personal/<int:id_personal>')
    api.add_resource(VistaFormularioAccidente, '/accidentes')
    api.add_resource(VistaAccidente, '/accidentes/<int:id_accidente>')
    api.add_resource(VistaReportesViajes, '/reportes')
    api.add_resource(VistaReporteViaje, '/reportes/<int:id_reporte>')

    return app
