 
import os
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_restful import Api
from flask_migrate import Migrate
import pymysql

# Importando el modelo donde tienes la instancia db
from .modelos.modelo import db

# Importando las vistas
from .vistas import VistaAmbulancias, VistaPersonalAmbulancia, VistaFormularioAccidente, VistaReportesViajes

def create_app(config_name='default'):
    app = Flask(__name__)
    
    # Cargar variables de entorno para la configuración de la base de datos
    db_user = os.getenv('DB_USER', 'root')  # Usuario de la base de datos
    db_password = os.getenv('DB_PASSWORD', '')  # Contraseña de la base de datos
    db_host = os.getenv('DB_HOST', 'localhost')  # Dirección del servidor MySQL
    db_name = os.getenv('DB_NAME', 'julian')  # Nombre de la base de datos

    # Configuración de la base de datos MySQL usando pymysql
    app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # Inicialización de la base de datos y migración
    db.init_app(app)
    migrate = Migrate(app, db)  # Inicializa Flask-Migrate correctamente

    # Configuración de la API RESTful
    api = Api(app)
    api.add_resource(VistaAmbulancias, '/ambulancias')  # Vista para todas las ambulancias
    api.add_resource(VistaPersonalAmbulancia, '/ambulancias/<int:id_ambulancia>/personal')  # Vista para el personal de una ambulancia
    api.add_resource(VistaFormularioAccidente, '/accidentes')  # Vista para los formularios de accidentes
    api.add_resource(VistaReportesViajes, '/reportes_viajes')  # Vista para los reportes de viajes de ambulancias

    return app
