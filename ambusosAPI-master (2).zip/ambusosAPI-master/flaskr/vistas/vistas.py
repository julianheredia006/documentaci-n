from flask import request
from flask_restful import Resource
from ..modelos import db, Ambulancia, Personal, FormularioAccidente, ReporteViajes, AmbulanciaSchema, PersonalSchema, FormularioAccidenteSchema, ReporteViajesSchema

# Esquemas para serializar los datos
ambulancia_schema = AmbulanciaSchema()
ambulancias_schema = AmbulanciaSchema(many=True)
personal_schema = PersonalSchema()
personales_schema = PersonalSchema(many=True)
formulario_accidente_schema = FormularioAccidenteSchema()
formulario_accidente_schema = FormularioAccidenteSchema(many=True)
reporte_viajes_schema = ReporteViajesSchema()
reportes_viajes_schema = ReporteViajesSchema(many=True)

# Vista para manejar todas las ambulancias
class VistaAmbulancias(Resource):
    def get(self):
        return ambulancias_schema.dump(Ambulancia.query.all())

    def post(self):
        nueva_ambulancia = Ambulancia(
            placa=request.json['placa'],
            categoria_ambulancia=request.json['categoria_ambulancia'],
            hospital_id=request.json.get('hospital_id')
        )
        db.session.add(nueva_ambulancia)
        db.session.commit()
        return ambulancia_schema.dump(nueva_ambulancia), 201

# Vista para manejar una ambulancia específica
class VistaAmbulancia(Resource):
    def get(self, id_ambulancia):
        ambulancia = Ambulancia.query.get_or_404(id_ambulancia)
        return ambulancia_schema.dump(ambulancia)

    def put(self, id_ambulancia):
        ambulancia = Ambulancia.query.get_or_404(id_ambulancia)
        ambulancia.placa = request.json.get('placa', ambulancia.placa)
        ambulancia.categoria_ambulancia = request.json.get('categoria_ambulancia', ambulancia.categoria_ambulancia)
        ambulancia.hospital_id = request.json.get('hospital_id', ambulancia.hospital_id)
        db.session.commit()
        return ambulancia_schema.dump(ambulancia)

    def delete(self, id_ambulancia):
        ambulancia = Ambulancia.query.get_or_404(id_ambulancia)
        db.session.delete(ambulancia)
        db.session.commit()
        return '', 204


# Vista para manejar el personal asignado a una ambulancia
class VistaPersonalAmbulancia(Resource):
    def get(self, id_ambulancia):
        personal = Personal.query.filter_by(ambulancia_id=id_ambulancia).all()
        return personales_schema.dump(personal)

    def post(self, id_ambulancia):
        nuevo_personal = Personal(
            nombre=request.json['nombre'],
            apellido=request.json['apellido'],
            numero_documento=request.json['numero_documento'],
            estado=request.json['estado'],
            correo=request.json['correo'],
            contraseña=request.json['contraseña'],
            rol_id=request.json['rol_id'],
            ambulancia_id=id_ambulancia
        )
        db.session.add(nuevo_personal)
        db.session.commit()
        return personal_schema.dump(nuevo_personal), 201

# Vista para manejar un miembro del personal asignado a una ambulancia
class VistaMiembroPersonal(Resource):
    def get(self, id_ambulancia, id_personal):
        personal = Personal.query.get_or_404(id_personal)
        return personal_schema.dump(personal)

    def put(self, id_ambulancia, id_personal):
        personal = Personal.query.get_or_404(id_personal)
        personal.nombre = request.json.get('nombre', personal.nombre)
        personal.apellido = request.json.get('apellido', personal.apellido)
        personal.numero_documento = request.json.get('numero_documento', personal.numero_documento)
        personal.estado = request.json.get('estado', personal.estado)
        personal.correo = request.json.get('correo', personal.correo)
        personal.rol_id = request.json.get('rol_id', personal.rol_id)
        db.session.commit()
        return personal_schema.dump(personal)

    def delete(self, id_ambulancia, id_personal):
        personal = Personal.query.get_or_404(id_personal)
        db.session.delete(personal)
        db.session.commit()
        return '', 204


# Vista para manejar los formularios de accidentes
class VistaFormularioAccidente(Resource):
    def get(self):
        return formulario_accidente_schema.dump(FormularioAccidente.query.all())

    def post(self):
        nuevo_accidente = FormularioAccidente(
            nombre=request.json['nombre'],
            apellido=request.json['apellido'],
            numero_documento=request.json['numero_documento'],
            genero=request.json['genero'],
            seguro_medico=request.json['seguro_medico'],
            reporte_accidente=request.json['reporte_accidente'],
            ubicacion=request.json['ubicacion'],
            EPS=request.json['EPS'],
            estado=request.json['estado'],
            ambulancia_id=request.json.get('ambulancia_id')
        )
        db.session.add(nuevo_accidente)
        db.session.commit()
        return formulario_accidente_schema.dump(nuevo_accidente), 201

# Vista para manejar un formulario de accidente específico
class VistaAccidente(Resource):
    def get(self, id_accidente):
        accidente = FormularioAccidente.query.get_or_404(id_accidente)
        return formulario_accidente_schema.dump(accidente)

    def put(self, id_accidente):
        accidente = FormularioAccidente.query.get_or_404(id_accidente)
        accidente.nombre = request.json.get('nombre', accidente.nombre)
        accidente.apellido = request.json.get('apellido', accidente.apellido)
        accidente.numero_documento = request.json.get('numero_documento', accidente.numero_documento)
        accidente.genero = request.json.get('genero', accidente.genero)
        accidente.seguro_medico = request.json.get('seguro_medico', accidente.seguro_medico)
        accidente.reporte_accidente = request.json.get('reporte_accidente', accidente.reporte_accidente)
        accidente.ubicacion = request.json.get('ubicacion', accidente.ubicacion)
        accidente.EPS = request.json.get('EPS', accidente.EPS)
        accidente.estado = request.json.get('estado', accidente.estado)
        accidente.ambulancia_id = request.json.get('ambulancia_id', accidente.ambulancia_id)
        db.session.commit()
        return formulario_accidente_schema.dump(accidente)

    def delete(self, id_accidente):
        accidente = FormularioAccidente.query.get_or_404(id_accidente)
        db.session.delete(accidente)
        db.session.commit()
        return '', 204


# Vista para manejar los reportes de viajes
class VistaReportesViajes(Resource):
    def get(self):
        return reportes_viajes_schema.dump(ReporteViajes.query.all())

    def post(self):
        nuevo_reporte = ReporteViajes(
            ambulancia_asignada=request.json['ambulancia_asignada'],
            tiempo=request.json['tiempo'],
            paciente=request.json.get('paciente'),
            punto_i=request.json.get('punto_i'),
            punto_f=request.json.get('punto_f'),
            accidente_id=request.json.get('accidente_id')
        )
        db.session.add(nuevo_reporte)
        db.session.commit()
        return reporte_viajes_schema.dump(nuevo_reporte), 201

# Vista para manejar un reporte de viaje específico
class VistaReporteViaje(Resource):
    def get(self, id_reporte):
        reporte = ReporteViajes.query.get_or_404(id_reporte)
        return reporte_viajes_schema.dump(reporte)

    def put(self, id_reporte):
        reporte = ReporteViajes.query.get_or_404(id_reporte)
        reporte.ambulancia_asignada = request.json.get('ambulancia_asignada', reporte.ambulancia_asignada)
        reporte.tiempo = request.json.get('tiempo', reporte.tiempo)
        reporte.paciente = request.json.get('paciente', reporte.paciente)
        reporte.punto_i = request.json.get('punto_i', reporte.punto_i)
        reporte.punto_f = request.json.get('punto_f', reporte.punto_f)
        reporte.accidente_id = request.json.get('accidente_id', reporte.accidente_id)
        db.session.commit()
        return reporte_viajes_schema.dump(reporte)

    def delete(self, id_reporte):
        reporte = ReporteViajes.query.get_or_404(id_reporte)
        db.session.delete(reporte)
        db.session.commit()
        return '', 204
