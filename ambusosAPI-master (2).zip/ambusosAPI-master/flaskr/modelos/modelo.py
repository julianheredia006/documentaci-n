from flask_sqlalchemy import SQLAlchemy
import enum
from marshmallow import fields
from marshmallow_sqlalchemy import SQLAlchemyAutoSchema

# Inicialización de la base de datos
db = SQLAlchemy()

# Definición de los enums

class RolesEnum(enum.Enum):
    ADMINISTRADOR = "Administrador"
    CONDUCTOR = "Conductor"
    ENFERMERO = "Enfermero"
    PARAMEDICO = "Paramédico"

class CategoriaAmbulanciaEnum(enum.Enum):
    BASICA = "Básica"
    MEDICALIZADA = "Medicalizada"
    UTIM = "UTIM"

class GeneroEnum(enum.Enum):
    MASCULINO = "M"
    FEMENINO = "F"
    OTRO = "Otro"

class EstadoEnum(enum.Enum):
    ACTIVO = "Activo"
    INACTIVO = "Inactivo"

class EstadoAccidenteEnum(enum.Enum):
    LEVE = "leve"
    MODERADO = "moderado"
    GRAVE = "grave"
    CRITICO = "critico"
    
    
class Roles(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.Enum(RolesEnum), nullable=False, unique=True)

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre.value
        }
# Modelos de la base de datos
class Hospital(db.Model):
    __tablename__ = 'hospitales'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(100), nullable=False, unique=True)
    direccion = db.Column(db.String(200), nullable=False)
    capacidad_atencion = db.Column(db.Integer, nullable=False)
    categoria = db.Column(db.Enum('General', 'Especializado', 'Clínica', 'Emergencias'), nullable=False)

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "direccion": self.direccion,
            "capacidad_atencion": self.capacidad_atencion,
            "categoria": self.categoria
        }


class Ambulancia(db.Model):
    __tablename__ = 'ambulancia'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    placa = db.Column(db.String(10), nullable=False, unique=True)
    categoria_ambulancia = db.Column(db.Enum(CategoriaAmbulanciaEnum), nullable=False)
    hospital_id = db.Column(db.Integer, db.ForeignKey('hospitales.id', ondelete='SET NULL'))

    def to_dict(self):
        return {
            "id": self.id,
            "placa": self.placa,
            "categoria_ambulancia": self.categoria_ambulancia.value,
            "hospital_id": self.hospital_id
        }
        
class Personal(db.Model):
    __tablename__ = 'personal'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(50), nullable=False)
    apellido = db.Column(db.String(50), nullable=False)
    numero_documento = db.Column(db.String(20), nullable=False, unique=True)
    estado = db.Column(db.Enum(EstadoEnum), nullable=False, default=EstadoEnum.ACTIVO)
    correo = db.Column(db.String(100), nullable=False, unique=True)
    contraseña = db.Column(db.String(100), nullable=False)
    rol_id = db.Column(db.Integer, db.ForeignKey('roles.id'), nullable=False)  # Clave foránea a la tabla roles
    ambulancia_id = db.Column(db.Integer, db.ForeignKey('ambulancia.id'), nullable=True)  # Relación con la tabla de ambulancias

    # Relaciones
    ambulancia = db.relationship('Ambulancia', backref='personal')  # Relación con la tabla de ambulancias
    rol = db.relationship('Roles', backref='personal')  # Relación con la tabla roles

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "apellido": self.apellido,
            "numero_documento": self.numero_documento,
            "estado": self.estado.value,
            "correo": self.correo,
            "rol_id": self.rol_id,  # Devuelve el id del rol
            "ambulancia_id": self.ambulancia_id
        }




class FormularioAccidente(db.Model):
    __tablename__ = 'formularioaccidente'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre = db.Column(db.String(50), nullable=False)
    apellido = db.Column(db.String(50), nullable=False)
    numero_documento = db.Column(db.String(255))
    genero = db.Column(db.Enum(GeneroEnum), nullable=False)
    seguro_medico = db.Column(db.String(100))
    reporte_accidente = db.Column(db.Text, nullable=False)
    fecha_reporte = db.Column(db.DateTime, nullable=False, default=db.func.current_timestamp())
    ubicacion = db.Column(db.String(255))
    EPS = db.Column(db.String(100), nullable=False)
    estado = db.Column(db.Enum(EstadoAccidenteEnum), nullable=False)
    ambulancia_id = db.Column(db.Integer, db.ForeignKey('ambulancia.id', ondelete='SET NULL'))

    def to_dict(self):
        return {
            "id": self.id,
            "nombre": self.nombre,
            "apellido": self.apellido,
            "numero_documento": self.numero_documento,
            "genero": self.genero.value,
            "seguro_medico": self.seguro_medico,
            "reporte_accidente": self.reporte_accidente,
            "fecha_reporte": self.fecha_reporte.isoformat() if self.fecha_reporte else None,
            "ubicacion": self.ubicacion,
            "EPS": self.EPS,
            "estado": self.estado.value,
            "ambulancia_id": self.ambulancia_id
        }
        
        
class ReporteViajes(db.Model):
    __tablename__ = 'reporte_viajes'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    ambulancia_asignada = db.Column(db.Integer, db.ForeignKey('ambulancia.id'), nullable=False)
    tiempo = db.Column(db.Time, nullable=False)
    paciente = db.Column(db.String(50), nullable=True)
    punto_i = db.Column(db.String(100), nullable=True)
    punto_f = db.Column(db.String(100), nullable=True)
    accidente_id = db.Column(db.Integer, db.ForeignKey('formularioaccidente.id'), nullable=True)

    ambulancia = db.relationship('Ambulancia', backref='reportes_viajes')
    accidente = db.relationship('FormularioAccidente', backref='reportes_viajes')

    def to_dict(self):
        return {
            "id": self.id,
            "ambulancia_asignada": self.ambulancia_asignada,
            "tiempo": str(self.tiempo) if self.tiempo else None,
            "paciente": self.paciente,
            "punto_i": self.punto_i,
            "punto_f": self.punto_f,
            "accidente_id": self.accidente_id
        }


           
           

