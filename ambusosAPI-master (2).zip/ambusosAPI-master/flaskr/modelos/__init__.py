from .modelo import db, Ambulancia, Personal, FormularioAccidente, ReporteViajes
from .esquemas import AmbulanciaSchema, PersonalSchema, FormularioAccidenteSchema, ReporteViajesSchema

__all__ = [
    "db",
    "Ambulancia",
    "Personal",
    "FormularioAccidente",
    "ReporteViajes",
    "AmbulanciaSchema",
    "PersonalSchema",
    "FormularioAccidenteSchema",
    "ReporteViajesSchema",
]
