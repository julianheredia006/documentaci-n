from marshmallow_sqlalchemy import SQLAlchemyAutoSchema
from .modelo import Hospital, Ambulancia, Personal, FormularioAccidente, ReporteViajes

class AmbulanciaSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Ambulancia
        include_relationships = True
        load_instance = True

class PersonalSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = Personal
        include_relationships = True
        load_instance = True

class FormularioAccidenteSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = FormularioAccidente
        include_relationships = True
        load_instance = True

class ReporteViajesSchema(SQLAlchemyAutoSchema):
    class Meta:
        model = ReporteViajes
        include_relationships = True
        load_instance = True
